import { useEffect, useRef, useState } from 'react';
import { Network, DataSet } from 'vis-network/standalone';
import { Link } from 'react-router-dom';
import { Zap, X, ShieldAlert, Cpu, Globe, Truck, MapPin, User, ArrowRight } from 'lucide-react';
import { sellers, deliveryPartners, transactions } from '@/data/mockData';
import type { Transaction } from '@/data/types';
import { RiskBadge } from '@/components/RiskBadge';

type EntityKind = 'seller' | 'device' | 'ip' | 'dp' | 'address';

interface SelectedInfo {
  kind: EntityKind;
  id: string;
  label: string;
  details: { key: string; value: string }[];
  txs: Transaction[];
  reasons: string[];
  riskScore?: number;
}

const NODE_STYLE: Record<EntityKind, { color: string; shape: string; icon: string }> = {
  seller: { color: '#6366f1', shape: 'dot', icon: 'User' },
  device: { color: '#f59e0b', shape: 'triangle', icon: 'Cpu' },
  ip: { color: '#ef4444', shape: 'diamond', icon: 'Globe' },
  dp: { color: '#10b981', shape: 'square', icon: 'Truck' },
  address: { color: '#a855f7', shape: 'dot', icon: 'MapPin' },
};

export function TrustGraph() {
  const containerRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<Network | null>(null);
  const [selected, setSelected] = useState<SelectedInfo | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!containerRef.current) return;

    const nodes = new DataSet<any, any>();
    const edges = new DataSet<any, any>();

    const fraudSellerIds = new Set<string>();
    transactions.forEach((t) => {
      if (t.status === 'fraud') fraudSellerIds.add(t.sellerId);
    });

    sellers.forEach((s) => {
      nodes.add({
        id: `seller:${s.id}`,
        label: s.name,
        group: 'seller',
        color: { background: NODE_STYLE.seller.color, border: '#818cf8', highlight: { background: '#818cf8', border: '#a5b4fc' } },
        shape: 'dot',
        size: 18,
        font: { color: '#e6eaf2', size: 12 },
        _kind: 'seller',
        _id: s.id,
      });
      nodes.add({
        id: `device:${s.deviceId}`,
        label: s.deviceId,
        group: 'device',
        color: { background: NODE_STYLE.device.color, border: '#fbbf24' },
        shape: 'triangle',
        size: 14,
        font: { color: '#fbbf24', size: 11 },
        _kind: 'device',
        _id: s.deviceId,
      });
      edges.add({ id: `e-sd-${s.id}`, from: `seller:${s.id}`, to: `device:${s.deviceId}`, color: { color: '#334155', highlight: '#f59e0b' }, width: 1.5 });

      nodes.add({
        id: `ip:${s.ip}`,
        label: s.ip,
        group: 'ip',
        color: { background: NODE_STYLE.ip.color, border: '#f87171' },
        shape: 'diamond',
        size: 13,
        font: { color: '#f87171', size: 11 },
        _kind: 'ip',
        _id: s.ip,
      });
      edges.add({ id: `e-sip-${s.id}`, from: `seller:${s.id}`, to: `ip:${s.ip}`, color: { color: '#334155', highlight: '#ef4444' }, width: 1.5 });
    });

    deliveryPartners.forEach((dp) => {
      nodes.add({
        id: `dp:${dp.id}`,
        label: dp.name,
        group: 'dp',
        color: { background: NODE_STYLE.dp.color, border: '#34d399' },
        shape: 'square',
        size: 14,
        font: { color: '#34d399', size: 11 },
        _kind: 'dp',
        _id: dp.id,
      });
    });

    const addrSet = new Set<string>();
    transactions.forEach((t) => {
      addrSet.add(t.address);
      edges.add({ id: `e-tx-${t.id}`, from: `seller:${t.sellerId}`, to: `dp:${t.deliveryPartnerId}`, color: { color: '#1e293b', opacity: 0.4 }, width: 0.5, dashes: true, hidden: true });
    });
    Array.from(addrSet).slice(0, 8).forEach((a) => {
      nodes.add({
        id: `addr:${a}`,
        label: a.slice(0, 18) + '…',
        group: 'address',
        color: { background: NODE_STYLE.address.color, border: '#c084fc' },
        shape: 'dot',
        size: 10,
        font: { color: '#c084fc', size: 10 },
        _kind: 'address',
        _id: a,
      });
    });

    transactions.forEach((t) => {
      edges.add({
        id: `e-taddr-${t.id}`,
        from: `seller:${t.sellerId}`,
        to: `addr:${t.address}`,
        color: { color: '#1e293b', opacity: 0.35 },
        width: 0.6,
        _tx: t.id,
      });
    });

    const data = { nodes, edges };
    const network = new Network(containerRef.current, data, {
      nodes: { borderWidth: 2 },
      edges: { smooth: { enabled: true, type: 'continuous', roundness: 0.5 } },
      physics: {
        barnesHut: { gravitationalConstant: -8000, springLength: 120, springConstant: 0.04, damping: 0.4 },
        stabilization: { iterations: 200 },
      },
      interaction: { hover: true, tooltipDelay: 120 },
    });
    networkRef.current = network;

    network.on('click', (params: any) => {
      if (params.nodes.length === 0) {
        setSelected(null);
        return;
      }
      const node = nodes.get(params.nodes[0]) as any;
      buildSelected(node);
    });

    network.once('stabilizationIterationsDone', () => {
      setLoading(false);
    });
    const fallback = setTimeout(() => setLoading(false), 1800);

    function buildSelected(node: any) {
      const kind = node._kind as EntityKind;
      const id = node._id as string;
      let info: SelectedInfo | null = null;
      if (kind === 'seller') {
        const s = sellers.find((x) => x.id === id)!;
        const txs = transactions.filter((t) => t.sellerId === id);
        const shared = sellers.filter((x) => x.deviceId === s.deviceId);
        info = {
          kind,
          id,
          label: s.name,
          details: [
            { key: 'Seller ID', value: s.id },
            { key: 'GSTIN', value: s.gstin },
            { key: 'Device', value: s.deviceId },
            { key: 'IP Address', value: s.ip },
            { key: 'Rating', value: s.rating.toFixed(1) },
            { key: 'Total Orders', value: s.totalOrders.toLocaleString('en-IN') },
            { key: 'Return Rate', value: `${(s.returnRate * 100).toFixed(0)}%` },
            { key: 'Sellers on same device', value: shared.map((x) => x.id).join(', ') },
          ],
          txs,
          reasons: txs[0]?.reasons ?? [],
          riskScore: txs[0]?.riskScore,
        };
      } else if (kind === 'device') {
        const shared = sellers.filter((x) => x.deviceId === id);
        info = {
          kind,
          id,
          label: id,
          details: [
            { key: 'Device ID', value: id },
            { key: 'Sellers sharing', value: shared.length.toString() },
            { key: 'Seller IDs', value: shared.map((s) => s.id).join(', ') },
          ],
          txs: transactions.filter((t) => t.deviceId === id),
          reasons: shared.length >= 3 ? [`Same device ${id} shared by ${shared.length} sellers - collusion pattern`] : [],
          riskScore: shared.length >= 3 ? 40 : 0,
        };
      } else if (kind === 'ip') {
        const shared = sellers.filter((x) => x.ip === id);
        info = {
          kind,
          id,
          label: id,
          details: [
            { key: 'IP Address', value: id },
            { key: 'Sellers on this IP', value: shared.length.toString() },
            { key: 'Seller IDs', value: shared.map((s) => s.id).join(', ') },
          ],
          txs: transactions.filter((t) => t.ip === id),
          reasons: [],
        };
      } else if (kind === 'dp') {
        const dp = deliveryPartners.find((x) => x.id === id)!;
        info = {
          kind,
          id,
          label: dp.name,
          details: [
            { key: 'Partner ID', value: dp.id },
            { key: 'Avg Delivery Time', value: `${dp.avgDeliveryTime} hrs` },
            { key: 'Fake Deliveries', value: dp.fakeDeliveryCount.toString() },
            { key: 'GPS Mismatches', value: dp.gpsMismatchCount.toString() },
          ],
          txs: transactions.filter((t) => t.deliveryPartnerId === id),
          reasons: dp.fakeDeliveryCount > 10 ? [`Delivery partner marked ${dp.fakeDeliveryCount} parcels delivered in 5 mins at same GPS - possible pilferage`] : [],
          riskScore: dp.fakeDeliveryCount > 10 ? 35 : 0,
        };
      } else if (kind === 'address') {
        const txs = transactions.filter((t) => t.address === id);
        info = {
          kind,
          id,
          label: id,
          details: [{ key: 'Address', value: id }, { key: 'Orders to this address', value: txs.length.toString() }],
          txs,
          reasons: txs.length > 5 ? [`IP cluster created ${txs.length}+ orders to same address cluster`] : [],
        };
      }
      setSelected(info);
    }

    return () => {
      clearTimeout(fallback);
      network.destroy();
      networkRef.current = null;
    };
  }, []);

  const detectCollusion = () => {
    if (!networkRef.current) return;
    setDetecting(true);
    const net = networkRef.current;
    const fraudIds = new Set(['seller:SELLER_001', 'seller:SELLER_002', 'seller:SELLER_003', 'device:DEV_01', 'ip:192.168.1.10', 'dp:DP_005']);
    const allNodes = (net as any).body.data.nodes.get() as any[];
    const updateNodes = allNodes.map((n) => {
      if (fraudIds.has(n.id)) {
        return { id: n.id, color: { background: '#ef4444', border: '#fca5a5' }, borderWidth: 4 };
      }
      return { id: n.id, color: { background: '#1e293b', border: '#334155' }, font: { color: '#475569' } };
    });
    (net as any).body.data.nodes.update(updateNodes);

    const allEdges = (net as any).body.data.edges.get() as any[];
    const updateEdges = allEdges.map((e: any) => {
      if (e.from === 'seller:SELLER_001' || e.from === 'seller:SELLER_002' || e.from === 'seller:SELLER_003') {
        if (e.to === 'device:DEV_01' || e.to === 'ip:192.168.1.10') {
          return { id: e.id, color: { color: '#ef4444' }, width: 3.5, dashes: false };
        }
      }
      return { id: e.id, color: { color: '#1e293b', opacity: 0.15 }, width: 0.5 };
    });
    (net as any).body.data.edges.update(updateEdges);

    net.focus('device:DEV_01', { scale: 1.4, animation: { duration: 800, easingFunction: 'easeInOutQuad' } });

    setTimeout(() => setDetecting(false), 2200);
  };

  const iconFor = (kind: EntityKind) => {
    const map = { seller: User, device: Cpu, ip: Globe, dp: Truck, address: MapPin };
    return map[kind];
  };

  return (
    <div className="relative">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 text-[11px]">
          {(Object.keys(NODE_STYLE) as EntityKind[]).map((k) => (
            <span key={k} className="flex items-center gap-1.5 text-[var(--color-text-muted)]">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: NODE_STYLE[k].color }} />
              {k === 'seller' ? 'Sellers' : k === 'device' ? 'Devices' : k === 'ip' ? 'IPs' : k === 'dp' ? 'Delivery' : 'Addresses'}
            </span>
          ))}
        </div>
        <button
          onClick={detectCollusion}
          disabled={detecting}
          className="group inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-4 py-2 text-sm font-medium text-white shadow-lg shadow-red-500/20 transition hover:shadow-red-500/40 disabled:opacity-70"
        >
          {detecting ? (
            <>
              <span className="h-3.5 w-3.5 animate-spin-slow rounded-full border-2 border-white/30 border-t-white" />
              Detecting...
            </>
          ) : (
            <>
              <Zap className="h-4 w-4" />
              Detect Collusion
            </>
          )}
        </button>
      </div>

      <div className="relative grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="relative h-[560px] overflow-hidden rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]">
          {loading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-[var(--color-surface)]">
              <div className="flex flex-col items-center gap-3">
                <div className="h-8 w-8 animate-spin-slow rounded-full border-2 border-indigo-500/30 border-t-indigo-400" />
                <span className="text-xs text-[var(--color-text-muted)]">Building entity graph...</span>
              </div>
            </div>
          )}
          <div ref={containerRef} className="h-full w-full" />
          <div className="pointer-events-none absolute bottom-3 left-3 rounded-lg bg-black/40 px-2.5 py-1.5 text-[11px] text-[var(--color-text-muted)] backdrop-blur">
            Drag to pan · Scroll to zoom · Click a node for details
          </div>
        </div>

        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4">
          {!selected ? (
            <div className="flex h-full flex-col items-center justify-center py-12 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10">
                <ShieldAlert className="h-6 w-6 text-indigo-300" />
              </div>
              <p className="mt-3 text-sm font-medium">No node selected</p>
              <p className="mt-1 max-w-[220px] text-xs text-[var(--color-text-muted)]">
                Click any node in the graph to inspect entity details, risk signals, and linked transactions.
              </p>
            </div>
          ) : (
            <div className="animate-slide-in space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  {(() => {
                    const Icon = iconFor(selected.kind);
                    return (
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ background: `${NODE_STYLE[selected.kind].color}22` }}>
                        <Icon className="h-4 w-4" style={{ color: NODE_STYLE[selected.kind].color }} />
                      </div>
                    );
                  })()}
                  <div>
                    <div className="text-sm font-semibold">{selected.label}</div>
                    <div className="text-[11px] uppercase tracking-wide text-[var(--color-text-dim)]">{selected.kind}</div>
                  </div>
                </div>
                <button onClick={() => setSelected(null)} className="rounded-md p-1 text-[var(--color-text-dim)] transition hover:text-[var(--color-text)]">
                  <X className="h-4 w-4" />
                </button>
              </div>

              {selected.riskScore !== undefined && selected.riskScore > 0 && (
                <div>
                  <RiskBadge score={selected.riskScore} />
                </div>
              )}

              <div className="space-y-2">
                {selected.details.map((d) => (
                  <div key={d.key} className="flex items-start justify-between gap-3 border-b border-[var(--color-border)]/60 pb-1.5 text-xs">
                    <span className="text-[var(--color-text-muted)]">{d.key}</span>
                    <span className="text-right font-medium">{d.value}</span>
                  </div>
                ))}
              </div>

              {selected.reasons.length > 0 && (
                <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3">
                  <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-red-300">Risk Signals</div>
                  <ul className="space-y-1.5">
                    {selected.reasons.map((r, i) => (
                      <li key={i} className="flex gap-2 text-xs text-red-200">
                        <span className="mt-0.5 h-1 w-1 shrink-0 rounded-full bg-red-400" />
                        {r}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div>
                <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-[var(--color-text-dim)]">
                  Linked Transactions ({selected.txs.length})
                </div>
                <div className="max-h-48 space-y-1.5 overflow-y-auto pr-1">
                  {selected.txs.slice(0, 10).map((t) => (
                    <Link
                      key={t.id}
                      to={`/case/${t.id}`}
                      className="flex items-center justify-between rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 px-2.5 py-1.5 text-xs transition hover:border-indigo-500/40"
                    >
                      <span className="font-mono text-[var(--color-text-muted)]">{t.id}</span>
                      <span className="flex items-center gap-2">
                        <span>₹{t.amount.toLocaleString('en-IN')}</span>
                        <span className={`h-1.5 w-1.5 rounded-full ${t.status === 'fraud' ? 'bg-red-500' : t.status === 'review' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                        <ArrowRight className="h-3 w-3 text-[var(--color-text-dim)]" />
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
