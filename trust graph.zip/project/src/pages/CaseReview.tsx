import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle2,
  ShieldAlert,
  ShieldX,
  UserCog,
  FileText,
  Upload,
  Send,
  Mail,
  Clock,
  Gavel,
  Lock,
  AlertTriangle,
} from 'lucide-react';
import { getTransaction, getSeller, getDeliveryPartner } from '@/data/mockData';
import { RiskBadge, riskColor } from '@/components/RiskBadge';
import { useCaseState } from '@/store/caseStore';
import type { CaseAction } from '@/data/types';

function EvidenceTimeline({ steps }: { steps: { label: string; detail: string; weight: number }[] }) {
  if (steps.length === 0) {
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-sm text-emerald-200">
        No risk signals triggered. Transaction passed all automated checks.
      </div>
    );
  }
  return (
    <ol className="relative space-y-4">
      {steps.map((s, i) => {
        const isLast = i === steps.length - 1;
        return (
          <li key={i} className="relative flex gap-3">
            <div className="flex flex-col items-center">
              <div className="flex h-7 w-7 items-center justify-center rounded-full border border-red-500/40 bg-red-500/15 text-[11px] font-semibold text-red-300">
                {i + 1}
              </div>
              {!isLast && <div className="mt-1 w-px flex-1 bg-gradient-to-b from-red-500/40 to-transparent" />}
            </div>
            <div className="flex-1 pb-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">{s.label}</span>
                <span className="rounded-md bg-red-500/10 px-1.5 py-0.5 font-mono text-[10px] text-red-300">+{s.weight}</span>
              </div>
              <p className="mt-0.5 text-xs text-[var(--color-text-muted)]">{s.detail}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function ActionButton({
  icon: Icon,
  title,
  desc,
  color,
  onClick,
  disabled,
  done,
}: {
  icon: React.ElementType;
  title: string;
  desc: string;
  color: string;
  onClick: () => void;
  disabled?: boolean;
  done?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || done}
      className={`group w-full rounded-xl border p-3.5 text-left transition disabled:opacity-60 ${color} ${done ? 'ring-1 ring-emerald-500/40' : 'hover:shadow-lg'}`}
    >
      <div className="flex items-center gap-2.5">
        <Icon className="h-5 w-5" />
        <span className="text-sm font-semibold">{title}</span>
        {done && <CheckCircle2 className="ml-auto h-4 w-4 text-emerald-400" />}
      </div>
      <p className="mt-1 text-xs opacity-80">{desc}</p>
    </button>
  );
}

export function CaseReview() {
  const { id } = useParams<{ id: string }>();
  const tx = id ? getTransaction(id) : undefined;
  const seller = tx ? getSeller(tx.sellerId) : undefined;
  const dp = tx ? getDeliveryPartner(tx.deliveryPartnerId) : undefined;
  const { caseActions, caseAppeals, caseAudit, takeAction, submitAppeal } = useCaseState(id ?? '');

  const [loading, setLoading] = useState(true);
  const [emailSent, setEmailSent] = useState(false);
  const [appealReason, setAppealReason] = useState('');
  const [docName, setDocName] = useState('');
  const [appealSubmitted, setAppealSubmitted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return (
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="skeleton h-96 rounded-2xl" />
        <div className="skeleton h-96 rounded-2xl" />
      </div>
    );
  }

  if (!tx || !seller) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ShieldAlert className="h-10 w-10 text-[var(--color-text-dim)]" />
        <p className="mt-3 text-sm text-[var(--color-text-muted)]">Case not found.</p>
        <Link to="/" className="mt-4 text-sm text-indigo-300 hover:text-indigo-200">
          Back to Dashboard
        </Link>
      </div>
    );
  }

  const score = tx.riskScore;
  const c = riskColor(score);
  const takenTypes = new Set(caseActions.map((a) => a.type));

  const handleSoft = () => {
    takeAction('soft', 'Soft Action: Payout Hold 48hrs + OTP Verification');
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 4000);
  };

  const handleAppeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!appealReason.trim()) return;
    submitAppeal(appealReason, docName || 'No document uploaded');
    setAppealSubmitted(true);
    setAppealReason('');
    setDocName('');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-[var(--color-text-muted)] transition hover:text-[var(--color-text)]">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold">{tx.id}</span>
            <span className={`rounded-md border px-2 py-0.5 text-[11px] ${c.bg} ${c.border} ${c.text}`}>{c.label}</span>
          </div>
          <h2 className="mt-1 text-lg font-semibold">{seller.name}</h2>
          <p className="text-xs text-[var(--color-text-muted)]">
            {seller.id} · GSTIN {seller.gstin} · ₹{tx.amount.toLocaleString('en-IN')}
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <RiskBadge score={score} />
          <div className="text-[11px] text-[var(--color-text-dim)]">
            Precision {(tx.precision * 100).toFixed(0)}% · {new Date(tx.timestamp).toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
          <div className="mb-4 flex items-center gap-2">
            <FileText className="h-4 w-4 text-indigo-300" />
            <h3 className="text-sm font-semibold">Evidence Trail</h3>
          </div>
          <EvidenceTimeline steps={tx.evidence} />

          <div className="mt-5 space-y-2 rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-[var(--color-text-dim)]">Transaction Context</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div><span className="text-[var(--color-text-muted)]">Customer</span><br />{tx.customerId}</div>
              <div><span className="text-[var(--color-text-muted)]">Device</span><br />{tx.deviceId}</div>
              <div><span className="text-[var(--color-text-muted)]">IP</span><br />{tx.ip}</div>
              <div><span className="text-[var(--color-text-muted)]">Delivery</span><br />{dp?.name ?? tx.deliveryPartnerId}</div>
              <div className="col-span-2"><span className="text-[var(--color-text-muted)]">Address</span><br />{tx.address}</div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
          <div className="mb-4 flex items-center gap-2">
            <Gavel className="h-4 w-4 text-amber-300" />
            <h3 className="text-sm font-semibold">Graduated Action Panel</h3>
          </div>

          <div className="space-y-3">
            {score < 40 && (
              <ActionButton
                icon={CheckCircle2}
                title="Allow - Genuine"
                desc="No action required. Release payout and close case."
                color="border-emerald-500/40 bg-emerald-500/10 text-emerald-200"
                onClick={() => takeAction('allow', 'Allowed - marked genuine')}
                done={takenTypes.has('allow')}
              />
            )}

            {score >= 40 && score <= 85 && (
              <>
                <ActionButton
                  icon={Clock}
                  title="Soft Action: Payout Hold 48hrs + OTP Verification"
                  desc="Hold seller payout for 48 hours. Trigger OTP via SendGrid to registered contact for identity confirmation."
                  color="border-amber-500/40 bg-amber-500/10 text-amber-200"
                  onClick={handleSoft}
                  done={takenTypes.has('soft')}
                />
                {emailSent && (
                  <div className="animate-fade-in flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-200">
                    <Mail className="mt-0.5 h-4 w-4 shrink-0" />
                    <div>
                      <div className="font-medium">OTP verification email sent (mock)</div>
                      <div className="opacity-80">From: verify@platform.in · To: {seller.name} · 6-digit OTP valid 10 min</div>
                    </div>
                  </div>
                )}
              </>
            )}

            {score > 85 && tx.precision > 0.95 && (
              <>
                <ActionButton
                  icon={ShieldX}
                  title="Hard Action: Suspend Account"
                  desc="High confidence fraud. Suspend seller account, freeze pending payouts, and block new listings."
                  color="border-red-500/40 bg-red-500/10 text-red-200"
                  onClick={() => takeAction('suspend', 'Account suspended - high confidence fraud')}
                  done={takenTypes.has('suspend')}
                />
                <button
                  onClick={() => takeAction('suspend', 'Appeal initiated by analyst')}
                  className="w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-2.5 text-center text-xs text-[var(--color-text-muted)] transition hover:border-red-500/40 hover:text-red-200"
                >
                  Appeal
                </button>
              </>
            )}

            {score > 85 && tx.precision <= 0.95 && (
              <ActionButton
                icon={UserCog}
                title="Route to Human Investigator"
                desc="High risk but confidence below threshold. Assign to manual review queue with full evidence pack."
                color="border-blue-500/40 bg-blue-500/10 text-blue-200"
                onClick={() => takeAction('route_human', 'Routed to human investigator')}
                done={takenTypes.has('route_human')}
              />
            )}
          </div>

          {caseActions.length > 0 && (
            <div className="mt-4 rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
              <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-[var(--color-text-dim)]">Actions taken</div>
              {caseActions.map((a: CaseAction, i: number) => (
                <div key={i} className="flex items-center justify-between py-1 text-xs">
                  <span>{a.label}</span>
                  <span className="text-[var(--color-text-dim)]">{new Date(a.takenAt).toLocaleTimeString('en-IN')}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
          <div className="mb-4 flex items-center gap-2">
            <Lock className="h-4 w-4 text-emerald-300" />
            <h3 className="text-sm font-semibold">Immutable Audit Log</h3>
          </div>
          {caseAudit.length === 0 ? (
            <p className="text-xs text-[var(--color-text-muted)]">No audit entries yet. Actions and appeals are recorded here permanently.</p>
          ) : (
            <div className="space-y-2">
              {caseAudit.map((a) => (
                <div key={a.id} className="flex items-start gap-2 rounded-lg border border-[var(--color-border)]/60 bg-[var(--color-surface-2)]/30 p-2.5">
                  <div className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                  <div className="flex-1">
                    <div className="text-xs font-medium">{a.action}</div>
                    <div className="text-[11px] text-[var(--color-text-dim)]">
                      {a.actor} · {new Date(a.timestamp).toLocaleString('en-IN')}
                    </div>
                  </div>
                  <span className="font-mono text-[10px] text-emerald-400/70">sealed</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
          <div className="mb-4 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-300" />
            <h3 className="text-sm font-semibold">Appeal Form</h3>
          </div>
          {appealSubmitted ? (
            <div className="animate-fade-in rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-sm text-emerald-200">
              <div className="font-medium">Appeal Submitted</div>
              <p className="mt-1 text-xs opacity-90">SLA 24hrs - A human investigator will review your evidence and respond.</p>
            </div>
          ) : (
            <form onSubmit={handleAppeal} className="space-y-3">
              <div>
                <label className="mb-1 block text-[11px] font-medium text-[var(--color-text-muted)]">Reason for appeal</label>
                <textarea
                  value={appealReason}
                  onChange={(e) => setAppealReason(e.target.value)}
                  rows={3}
                  placeholder="Explain why this decision should be reconsidered..."
                  className="w-full resize-none rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 px-3 py-2 text-sm text-[var(--color-text)] outline-none transition focus:border-indigo-500/50"
                />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-medium text-[var(--color-text-muted)]">Supporting document</label>
                <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-[var(--color-border)] bg-[var(--color-surface-2)]/30 px-3 py-2.5 text-xs text-[var(--color-text-muted)] transition hover:border-indigo-500/40">
                  <Upload className="h-4 w-4" />
                  {docName || 'Upload invoice / ID proof (PDF, image)'}
                  <input
                    type="file"
                    className="hidden"
                    onChange={(e) => setDocName(e.target.files?.[0]?.name ?? '')}
                  />
                </label>
              </div>
              <button
                type="submit"
                disabled={!appealReason.trim()}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-indigo-500 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-600 disabled:opacity-50"
              >
                <Send className="h-4 w-4" /> Submit Appeal
              </button>
            </form>
          )}
          {caseAppeals.length > 0 && (
            <div className="mt-3 text-[11px] text-[var(--color-text-dim)]">
              {caseAppeals.length} appeal{caseAppeals.length !== 1 ? 's' : ''} on record for this case.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
