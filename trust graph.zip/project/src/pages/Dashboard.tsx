import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, ShieldX, Wallet, Clock, ArrowRight, AlertTriangle, CheckCircle2, HelpCircle } from 'lucide-react';
import { transactions, getSeller } from '@/data/mockData';
import { RiskBadge, RiskBar, riskColor } from '@/components/RiskBadge';
import { useAllAudit } from '@/store/caseStore';

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
  delay,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  accent: string;
  delay: number;
}) {
  return (
    <div
      className="animate-fade-in rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4 transition hover:border-[var(--color-border)]/80 hover:shadow-lg hover:shadow-black/20"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${accent}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-tight">{value}</div>
      <div className="text-xs text-[var(--color-text-muted)]">{label}</div>
      <div className="mt-2 text-[11px] text-[var(--color-text-dim)]">{sub}</div>
    </div>
  );
}

export function Dashboard() {
  const [loading, setLoading] = useState(true);
  const audit = useAllAudit();

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 650);
    return () => clearTimeout(t);
  }, []);

  const total = transactions.length;
  const fraud = transactions.filter((t) => t.status === 'fraud');
  const fraudCount = fraud.length;
  const moneySaved = fraud.reduce((s, t) => s + t.amount, 0) + 840000;
  const reviewCount = transactions.filter((t) => t.status === 'review').length;
  const genuineCount = transactions.filter((t) => t.status === 'genuine').length;

  const dist = [
    { name: 'Genuine', value: genuineCount, color: '#10b981' },
    { name: 'Review', value: reviewCount, color: '#f59e0b' },
    { name: 'Fraud', value: fraudCount, color: '#ef4444' },
  ];

  const highRisk = [...transactions].sort((a, b) => b.riskScore - a.riskScore).slice(0, 8);

  if (loading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton h-32 rounded-2xl" />
        ))}
        <div className="skeleton col-span-full h-72 rounded-2xl" />
        <div className="skeleton col-span-full h-96 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={TrendingUp} label="Total Transactions" value={total.toString()} sub="Last 7 days · 50 sampled" accent="bg-indigo-500/15 text-indigo-300" delay={0} />
        <StatCard icon={ShieldX} label="Fraud Blocked" value={fraudCount.toString()} sub={`${reviewCount} in review queue`} accent="bg-red-500/15 text-red-300" delay={60} />
        <StatCard
          icon={Wallet}
          label="Money Saved"
          value={`₹${(moneySaved / 100000).toFixed(1)}L`}
          sub="Cumulative · chargebacks prevented"
          accent="bg-emerald-500/15 text-emerald-300"
          delay={120}
        />
        <StatCard
          icon={Clock}
          label="Avg Investigation Time"
          value="2.3 min"
          sub="vs 45 min before automation"
          accent="bg-cyan-500/15 text-cyan-300"
          delay={180}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold">Risk Distribution</h2>
              <p className="text-xs text-[var(--color-text-muted)]">Outcomes across all transactions</p>
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              {dist.map((d) => (
                <span key={d.name} className="flex items-center gap-1.5 text-[var(--color-text-muted)]">
                  <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                  {d.name}
                </span>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={dist} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fill: '#8b95a9', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#8b95a9', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip
                cursor={{ fill: 'rgba(255,255,255,0.04)' }}
                contentStyle={{
                  background: '#111726',
                  border: '1px solid #1f2940',
                  borderRadius: 10,
                  fontSize: 12,
                  color: '#e6eaf2',
                }}
              />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={90}>
                {dist.map((d) => (
                  <Cell key={d.name} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
          <h2 className="text-sm font-semibold">Fairness & Cost</h2>
          <p className="text-xs text-[var(--color-text-muted)]">Bias and unit-economics metrics</p>
          <div className="mt-4 space-y-3">
            <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[var(--color-text-muted)]">Action rate - Small sellers</span>
                <span className="text-sm font-semibold text-amber-300">4.2%</span>
              </div>
              <RiskBar score={42} />
            </div>
            <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[var(--color-text-muted)]">Action rate - Large sellers</span>
                <span className="text-sm font-semibold text-emerald-300">4.0%</span>
              </div>
              <RiskBar score={40} />
            </div>
            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-200">
              No statistically significant bias detected (Δ 0.2pp)
            </div>
            <div className="flex items-center justify-between rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)]/40 p-3">
              <span className="text-xs text-[var(--color-text-muted)]">Cost per decision</span>
              <span className="text-sm font-semibold text-indigo-300">₹0.40</span>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]">
        <div className="flex items-center justify-between border-b border-[var(--color-border)] px-5 py-4">
          <div>
            <h2 className="text-sm font-semibold">Recent High-Risk Cases</h2>
            <p className="text-xs text-[var(--color-text-muted)]">Sorted by risk score · click to review</p>
          </div>
          <Link to="/graph" className="flex items-center gap-1 text-xs text-indigo-300 transition hover:text-indigo-200">
            Open Trust Graph <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-[var(--color-border)] text-[11px] uppercase tracking-wide text-[var(--color-text-dim)]">
                <th className="px-5 py-2.5 font-medium">Case</th>
                <th className="px-5 py-2.5 font-medium">Seller</th>
                <th className="px-5 py-2.5 font-medium">Amount</th>
                <th className="px-5 py-2.5 font-medium">Signal</th>
                <th className="px-5 py-2.5 font-medium">Risk</th>
                <th className="px-5 py-2.5 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {highRisk.map((t, i) => {
                const s = getSeller(t.sellerId);
                const c = riskColor(t.riskScore);
                return (
                  <tr key={t.id} className="border-b border-[var(--color-border)]/60 transition hover:bg-white/[0.02]">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-[var(--color-text-muted)]">{t.id}</span>
                        {t.status === 'fraud' ? (
                          <AlertTriangle className="h-3.5 w-3.5 text-red-400" />
                        ) : t.status === 'review' ? (
                          <HelpCircle className="h-3.5 w-3.5 text-amber-400" />
                        ) : (
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <div className="text-xs font-medium">{s?.name ?? t.sellerId}</div>
                      <div className="font-mono text-[11px] text-[var(--color-text-dim)]">{s?.gstin}</div>
                    </td>
                    <td className="px-5 py-3 text-xs">₹{t.amount.toLocaleString('en-IN')}</td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] ${c.bg} ${c.border} ${c.text}`}>
                        {t.reasons[0]?.split(' - ')[0] ?? 'Clean'}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <RiskBadge score={t.riskScore} size="sm" />
                      </div>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link to={`/case/${t.id}`} className="inline-flex items-center gap-1 rounded-lg border border-[var(--color-border)] px-2.5 py-1 text-[11px] text-[var(--color-text-muted)] transition hover:border-indigo-500/40 hover:text-indigo-300">
                        Review <ArrowRight className="h-3 w-3" />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {audit.length > 0 && (
          <div className="border-t border-[var(--color-border)] px-5 py-3 text-[11px] text-[var(--color-text-dim)]">
            {audit.length} action{audit.length !== 1 ? 's' : ''} logged in immutable audit trail
          </div>
        )}
      </div>
    </div>
  );
}
