import type {
  Seller,
  DeliveryPartner,
  Transaction,
  EvidenceStep,
} from './types';

export const sellers: Seller[] = [
  { id: 'SELLER_001', name: 'Sharma Electronics Hub', gstin: '07AABCT1332L1Z5', deviceId: 'DEV_01', ip: '192.168.1.10', rating: 4.8, totalOrders: 1240, returnRate: 0.38, size: 'small' },
  { id: 'SELLER_002', name: 'Verma Gadget Bazaar', gstin: '07AABCT9988K1Z2', deviceId: 'DEV_01', ip: '192.168.1.10', rating: 4.6, totalOrders: 980, returnRate: 0.42, size: 'small' },
  { id: 'SELLER_003', name: 'Mehta Mobile Store', gstin: '07AABCT5566P1Z9', deviceId: 'DEV_01', ip: '192.168.1.10', rating: 4.2, totalOrders: 760, returnRate: 0.51, size: 'small' },
  { id: 'SELLER_004', name: 'Patel Premium Goods', gstin: '37AABCT1332L1Z5', deviceId: 'DEV_02', ip: '192.168.1.20', rating: 4.9, totalOrders: 5200, returnRate: 0.08, size: 'large' },
  { id: 'SELLER_005', name: 'Reddy Textiles', gstin: '29AABCR5544Q1Z8', deviceId: 'DEV_03', ip: '192.168.1.30', rating: 4.7, totalOrders: 3100, returnRate: 0.11, size: 'large' },
  { id: 'SELLER_006', name: 'Iyer Kitchenware', gstin: '33AAACI8010R1Z1', deviceId: 'DEV_04', ip: '192.168.1.40', rating: 4.5, totalOrders: 1800, returnRate: 0.15, size: 'small' },
  { id: 'SELLER_007', name: 'Singh Sports Gear', gstin: '27AAFCS1234M1Z3', deviceId: 'DEV_05', ip: '192.168.1.50', rating: 4.4, totalOrders: 2400, returnRate: 0.13, size: 'large' },
  { id: 'SELLER_008', name: 'Nair Home Decor', gstin: '07AABCT7777T1Z4', deviceId: 'DEV_06', ip: '192.168.1.60', rating: 4.1, totalOrders: 620, returnRate: 0.33, size: 'small' },
  { id: 'SELLER_009', name: 'Gupta Book House', gstin: '06AABCG8855N1Z6', deviceId: 'DEV_07', ip: '192.168.1.70', rating: 4.8, totalOrders: 4100, returnRate: 0.06, size: 'large' },
  { id: 'SELLER_010', name: 'Joshi Pharma Supply', gstin: '24AABCJ2233P1Z7', deviceId: 'DEV_08', ip: '192.168.1.80', rating: 4.6, totalOrders: 2900, returnRate: 0.09, size: 'large' },
  { id: 'SELLER_011', name: 'Kapoor Cosmetics', gstin: '07AABCK4444L1Z0', deviceId: 'DEV_09', ip: '192.168.1.90', rating: 3.9, totalOrders: 410, returnRate: 0.47, size: 'small' },
  { id: 'SELLER_012', name: 'Rao Organic Foods', gstin: '29AABCR9012T1Z5', deviceId: 'DEV_10', ip: '192.168.1.100', rating: 4.7, totalOrders: 3600, returnRate: 0.07, size: 'large' },
  { id: 'SELLER_013', name: 'Malik Footwear Mart', gstin: '07AABCM6655K1Z1', deviceId: 'DEV_11', ip: '192.168.1.110', rating: 4.0, totalOrders: 540, returnRate: 0.36, size: 'small' },
  { id: 'SELLER_014', name: 'Chopra Fitness Equip', gstin: '09AABCC3344R1Z2', deviceId: 'DEV_12', ip: '192.168.1.120', rating: 4.5, totalOrders: 2200, returnRate: 0.12, size: 'large' },
  { id: 'SELLER_015', name: 'Bose Audio World', gstin: '19AABCB7788N1Z3', deviceId: 'DEV_13', ip: '192.168.1.130', rating: 4.6, totalOrders: 2800, returnRate: 0.10, size: 'large' },
];

export const deliveryPartners: DeliveryPartner[] = [
  { id: 'DP_001', name: 'Rajesh Kumar', avgDeliveryTime: 2.4, fakeDeliveryCount: 0, gpsMismatchCount: 1 },
  { id: 'DP_002', name: 'Suresh Yadav', avgDeliveryTime: 3.1, fakeDeliveryCount: 2, gpsMismatchCount: 3 },
  { id: 'DP_003', name: 'Amit Verma', avgDeliveryTime: 1.9, fakeDeliveryCount: 0, gpsMismatchCount: 0 },
  { id: 'DP_004', name: 'Vikram Singh', avgDeliveryTime: 2.8, fakeDeliveryCount: 4, gpsMismatchCount: 2 },
  { id: 'DP_005', name: 'Deepak Sharma', avgDeliveryTime: 1.2, fakeDeliveryCount: 15, gpsMismatchCount: 12 },
  { id: 'DP_006', name: 'Manoj Tiwari', avgDeliveryTime: 2.6, fakeDeliveryCount: 1, gpsMismatchCount: 1 },
  { id: 'DP_007', name: 'Sanjay Patel', avgDeliveryTime: 3.4, fakeDeliveryCount: 0, gpsMismatchCount: 0 },
  { id: 'DP_008', name: 'Ramesh Gupta', avgDeliveryTime: 2.2, fakeDeliveryCount: 3, gpsMismatchCount: 4 },
];

const addresses = [
  '12 MG Road, Bengaluru 560001',
  '44 Linking Road, Mumbai 400050',
  '78 Park Street, Kolkata 700016',
  '23 Connaught Place, New Delhi 110001',
  '56 Banjara Hills, Hyderabad 500034',
  '90 Anna Salai, Chennai 600002',
  '17 FC Road, Pune 411005',
  '33 Marine Drive, Kochi 682031',
];

const customerIds = Array.from({ length: 20 }, (_, i) => `CUST_${String(i + 1).padStart(3, '0')}`);

function isGstInvalid(gstin: string): boolean {
  return gstin.startsWith('07') || !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstin);
}

function sellersSharingDevice(deviceId: string): Seller[] {
  return sellers.filter((s) => s.deviceId === deviceId);
}

function txsFromIpToAddress(ip: string, address: string, all: { ip: string; address: string }[]): number {
  return all.filter((t) => t.ip === ip && t.address === address).length;
}

export interface RiskResult {
  score: number;
  reasons: string[];
  evidence: EvidenceStep[];
  precision: number;
}

export function calculateRisk(
  seller: Seller,
  ctx: { ip: string; address: string; deliveryPartnerId: string; amount: number },
  allTxs: { ip: string; address: string }[],
): RiskResult {
  let score = 0;
  const reasons: string[] = [];
  const evidence: EvidenceStep[] = [];

  const shared = sellersSharingDevice(seller.deviceId);
  if (shared.length >= 3) {
    score += 40;
    const r = `Same device ${seller.deviceId} shared by ${shared.length} sellers - collusion pattern`;
    reasons.push(r);
    evidence.push({ label: 'Device Sharing Collusion', detail: r, weight: 40 });
  }

  const sameClusterCount = txsFromIpToAddress(ctx.ip, ctx.address, allTxs);
  if (sameClusterCount > 5) {
    score += 30;
    const r = `IP ${ctx.ip} created ${sameClusterCount}+ orders to same address cluster`;
    reasons.push(r);
    evidence.push({ label: 'IP Abuse / Self-Ordering', detail: r, weight: 30 });
  }

  if (isGstInvalid(seller.gstin)) {
    score += 20;
    const r = seller.gstin.startsWith('07')
      ? `GSTIN ${seller.gstin} flagged - 07 series under review for legitimacy`
      : `Invalid GSTIN ${seller.gstin} - seller legitimacy failed`;
    reasons.push(r);
    evidence.push({ label: 'GSTIN Verification Failed', detail: r, weight: 20 });
  }

  const dp = deliveryPartners.find((d) => d.id === ctx.deliveryPartnerId);
  if (dp && dp.fakeDeliveryCount > 10) {
    score += 35;
    const r = `Delivery partner ${dp.name} marked ${dp.fakeDeliveryCount} parcels delivered in 5 mins at same GPS - possible pilferage`;
    reasons.push(r);
    evidence.push({ label: 'Delivery Fraud Detected', detail: r, weight: 35 });
  }

  if (seller.returnRate > 0.35) {
    score += 10;
    const r = `Abnormal return rate ${(seller.returnRate * 100).toFixed(0)}% - quality signal`;
    reasons.push(r);
    evidence.push({ label: 'High Return Rate', detail: r, weight: 10 });
  }

  const finalScore = Math.min(99, score);
  const precision = finalScore > 85 ? 0.96 : finalScore >= 40 ? 0.78 : 0.99;

  return { score: finalScore, reasons, evidence, precision };
}

function statusFromScore(score: number): Transaction['status'] {
  if (score > 85) return 'fraud';
  if (score >= 40) return 'review';
  return 'genuine';
}

function buildTransactions(): Transaction[] {
  const txs: Transaction[] = [];
  const baseTime = Date.now() - 1000 * 60 * 60 * 24 * 7;
  const draftTxs: { ip: string; address: string }[] = [];

  const plan: { sellerIdx: number; dpIdx: number; addrIdx: number; custIdx: number; amount: number; ipOverride?: string; addrOverride?: string }[] = [];
  for (let i = 0; i < 50; i++) {
    const sellerIdx = i % sellers.length;
    const dpIdx = i % deliveryPartners.length;
    const addrIdx = i % addresses.length;
    const custIdx = i % customerIds.length;
    const amount = Math.round((Math.random() * 45000 + 500) / 10) * 10;
    plan.push({ sellerIdx, dpIdx, addrIdx, custIdx, amount });
  }

  plan.forEach((p) => {
    const s = sellers[p.sellerIdx];
    draftTxs.push({ ip: s.ip, address: addresses[p.addrIdx] });
  });

  plan.forEach((p, i) => {
    const s = sellers[p.sellerIdx];
    const dp = deliveryPartners[p.dpIdx];
    const addr = addresses[p.addrIdx];
    const cust = customerIds[p.custIdx];
    const ctx = { ip: s.ip, address: addr, deliveryPartnerId: dp.id, amount: p.amount };
    const risk = calculateRisk(s, ctx, draftTxs);
    txs.push({
      id: `TX_${String(i + 1).padStart(4, '0')}`,
      sellerId: s.id,
      customerId: cust,
      amount: p.amount,
      ip: s.ip,
      deviceId: s.deviceId,
      address: addr,
      deliveryPartnerId: dp.id,
      riskScore: risk.score,
      status: statusFromScore(risk.score),
      reasons: risk.reasons,
      evidence: risk.evidence,
      precision: risk.precision,
      timestamp: new Date(baseTime + i * 1000 * 60 * 23).toISOString(),
    });
  });

  return txs;
}

export const transactions: Transaction[] = buildTransactions();

export function getSeller(id: string): Seller | undefined {
  return sellers.find((s) => s.id === id);
}
export function getDeliveryPartner(id: string): DeliveryPartner | undefined {
  return deliveryPartners.find((d) => d.id === id);
}
export function getTransaction(id: string): Transaction | undefined {
  return transactions.find((t) => t.id === id);
}
