export type SellerSize = 'small' | 'large';

export interface Seller {
  id: string;
  name: string;
  gstin: string;
  deviceId: string;
  ip: string;
  rating: number;
  totalOrders: number;
  returnRate: number;
  size: SellerSize;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  avgDeliveryTime: number;
  fakeDeliveryCount: number;
  gpsMismatchCount: number;
}

export type TxStatus = 'genuine' | 'review' | 'fraud';

export interface Transaction {
  id: string;
  sellerId: string;
  customerId: string;
  amount: number;
  ip: string;
  deviceId: string;
  address: string;
  deliveryPartnerId: string;
  riskScore: number;
  status: TxStatus;
  reasons: string[];
  evidence: EvidenceStep[];
  precision: number;
  timestamp: string;
}

export interface EvidenceStep {
  label: string;
  detail: string;
  weight: number;
}

export interface AuditEntry {
  id: string;
  caseId: string;
  actor: string;
  action: string;
  timestamp: string;
}

export interface AppealRecord {
  caseId: string;
  reason: string;
  documentName: string;
  submittedAt: string;
}

export interface CaseAction {
  caseId: string;
  type: 'allow' | 'soft' | 'suspend' | 'route_human';
  label: string;
  takenAt: string;
}
