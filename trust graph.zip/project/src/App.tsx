import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Sidebar, MobileNav } from '@/components/Sidebar';
import { Topbar } from '@/components/Topbar';
import { ComplianceBadges } from '@/components/ComplianceBadges';

const Dashboard = lazy(() => import('@/pages/Dashboard').then((m) => ({ default: m.Dashboard })));
const TrustGraph = lazy(() => import('@/pages/TrustGraph').then((m) => ({ default: m.TrustGraph })));
const CaseReview = lazy(() => import('@/pages/CaseReview').then((m) => ({ default: m.CaseReview })));

function PageFallback() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="skeleton h-32 rounded-2xl" />
      ))}
      <div className="skeleton col-span-full h-72 rounded-2xl" />
    </div>
  );
}

const titles: Record<string, { title: string; subtitle: string }> = {
  '/': { title: 'Risk Overview', subtitle: 'Real-time fraud signals across your marketplace' },
  '/graph': { title: 'Trust Graph', subtitle: 'Entity relationships and collusion detection' },
};

function Shell() {
  const location = useLocation();
  const isCase = location.pathname.startsWith('/case/');
  const meta = titles[location.pathname] ?? { title: 'Case Review', subtitle: 'Evidence trail and remediation' };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <MobileNav />
        <Topbar title={meta.title} subtitle={meta.subtitle} />
        <main className="flex-1 px-4 py-5 md:px-6">
          <Suspense fallback={<PageFallback />}>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/graph" element={<TrustGraph />} />
              <Route path="/case/:id" element={<CaseReview />} />
            </Routes>
          </Suspense>
        </main>
        <footer className="border-t border-[var(--color-border)] px-4 py-3 md:px-6">
          <div className="flex flex-col items-start gap-2 md:flex-row md:items-center md:justify-between">
            <p className="text-[11px] text-[var(--color-text-dim)]">
              Trust Graph Fraud Detection · Rules engine + open-source graph · Data persisted locally for demo
            </p>
            <div className="md:hidden">
              <ComplianceBadges />
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Shell />
    </BrowserRouter>
  );
}

export default App;
