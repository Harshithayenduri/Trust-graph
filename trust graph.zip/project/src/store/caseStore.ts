import { useEffect, useState, useCallback } from 'react';
import type { AuditEntry, AppealRecord, CaseAction } from '@/data/types';

const KEYS = {
  actions: 'tg_actions',
  appeals: 'tg_appeals',
  audit: 'tg_audit',
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function useCaseState(caseId: string) {
  const [actions, setActions] = useState<CaseAction[]>(() => read<CaseAction[]>(KEYS.actions, []));
  const [appeals, setAppeals] = useState<AppealRecord[]>(() => read<AppealRecord[]>(KEYS.appeals, []));
  const [audit, setAudit] = useState<AuditEntry[]>(() => read<AuditEntry[]>(KEYS.audit, []));

  const persist = useCallback(
    (next: { actions?: CaseAction[]; appeals?: AppealRecord[]; audit?: AuditEntry[] }) => {
      if (next.actions) {
        setActions(next.actions);
        write(KEYS.actions, next.actions);
      }
      if (next.appeals) {
        setAppeals(next.appeals);
        write(KEYS.appeals, next.appeals);
      }
      if (next.audit) {
        setAudit(next.audit);
        write(KEYS.audit, next.audit);
      }
    },
    [],
  );

  const takeAction = useCallback(
    (type: CaseAction['type'], label: string) => {
      const entry: CaseAction = { caseId, type, label, takenAt: new Date().toISOString() };
      const nextActions = [...read<CaseAction[]>(KEYS.actions, []), entry];
      const auditEntry: AuditEntry = {
        id: `AUD_${Date.now()}`,
        caseId,
        actor: 'risk-analyst@platform',
        action: label,
        timestamp: new Date().toISOString(),
      };
      const nextAudit = [...read<AuditEntry[]>(KEYS.audit, []), auditEntry];
      persist({ actions: nextActions, audit: nextAudit });
    },
    [caseId, persist],
  );

  const submitAppeal = useCallback(
    (reason: string, documentName: string) => {
      const rec: AppealRecord = { caseId, reason, documentName, submittedAt: new Date().toISOString() };
      const nextAppeals = [...read<AppealRecord[]>(KEYS.appeals, []), rec];
      const auditEntry: AuditEntry = {
        id: `AUD_${Date.now()}`,
        caseId,
        actor: 'seller-portal@platform',
        action: `Appeal submitted - ${documentName}`,
        timestamp: new Date().toISOString(),
      };
      const nextAudit = [...read<AuditEntry[]>(KEYS.audit, []), auditEntry];
      persist({ appeals: nextAppeals, audit: nextAudit });
    },
    [caseId, persist],
  );

  const caseActions = actions.filter((a) => a.caseId === caseId);
  const caseAppeals = appeals.filter((a) => a.caseId === caseId);
  const caseAudit = audit.filter((a) => a.caseId === caseId);

  return { caseActions, caseAppeals, caseAudit, takeAction, submitAppeal };
}

export function useAllAudit(): AuditEntry[] {
  const [audit, setAudit] = useState<AuditEntry[]>(() => read<AuditEntry[]>(KEYS.audit, []));
  useEffect(() => {
    const handler = () => setAudit(read<AuditEntry[]>(KEYS.audit, []));
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);
  return audit;
}
